def gray_img(path):

  img = cv2.imread(path, 0)
  return img

def show_img(path):
  img = cv2.imread(path)
  return img

def laplacian(path, rgb = True):

  img = None
  if rgb:
    img = show_img(path)
  else:  
    img = gray_img(path)
  ddepth = cv2.CV_16S
  kernel_size = 3
  src = cv2.GaussianBlur(img, (3, 3), 0)
  dst = cv2.Laplacian(src, ddepth, ksize=kernel_size)
  abs_dst = cv2.convertScaleAbs(dst)
  
  return abs_dst

def laplacian_data_generator(normal_folder_path, oscc_folder_path, rgb = True):
  
  x = []
  y = []
  for i in tqdm(os.listdir(normal_folder_path)):
    path = os.path.join(normal_folder_path, i)
    img = laplacian(path, rgb)
    x.append(img)
    y.append(0)

  for i in tqdm(os.listdir(oscc_folder_path)):
    path = os.path.join(oscc_folder_path, i)
    img = laplacian(path, rgb)
    x.append(img)
    y.append(1)

  return np.array(x), np.array(y)

# plt.imshow(laplacian("/content/First Set/100x OSCC Histopathological Images/OSCC_100x_329.jpg"), cmap = "gray")
lap_x, lap_y = laplacian_data_generator("/content/First Set/100x Normal Oral Cavity Histopathological Images", "/content/First Set/100x OSCC Histopathological Images", True)