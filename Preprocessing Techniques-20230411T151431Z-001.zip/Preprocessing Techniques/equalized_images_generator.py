def gray_img(path, resize = None):
  img = cv2.imread(path, 0)
  if resize != None:
    img = cv2.resize(img, resize, interpolation = cv2.INTER_NEAREST)
  return img

def equalize_histogram(path, size):
  img = gray_img(path, size)
  img = cv2.equalizeHist(img)
  return img

def equalize_histogram_generator(normal_folder_path, oscc_folder_path, size):
  
  x = []
  y = []
  for i in tqdm(os.listdir(normal_folder_path)):
    path = os.path.join(normal_folder_path, i)
    img = equalize_histogram(path, size)
    img = img.reshape(size + (1,))
    x.append(img)
    y.append(0)

  for i in tqdm(os.listdir(oscc_folder_path)):
    path = os.path.join(oscc_folder_path, i)
    img = equalize_histogram(path, size)
    img = img.reshape(size + (1,))
    x.append(img)
    y.append(1)

  return np.array(x), np.array(y)

equalized_imgs_x, equalized_imgs_labels = equalize_histogram_generator("/content/First Set/100x Normal Oral Cavity Histopathological Images", "/content/First Set/100x OSCC Histopathological Images", (224, 224))